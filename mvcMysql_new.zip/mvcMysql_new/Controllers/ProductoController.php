<?php
class ProductoController
{
    //atributos
    //constructor
    //getters y setters
    //otros
    function __constructor()
    {

    }

    function index()
    {
        require_once('Views/Producto/bienvenido.php');
    }

    function register()
    {
        require_once('Views/Producto/register.php');
    }
    
    function save()
    {
        $producto = new Producto(null,'fhfhg','20','50.99');
        Producto::save($producto);
    }
}//cierra clase