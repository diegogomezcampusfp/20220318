<?php
class ProductoController
{
    //atributos
    //constructor
    //getters y setters
    //otros
    function __constructor()
    {

    }

    function index()
    {
        require_once('Views/Producto/bienvenido.php');
    }

    function register()
    {
        require_once('Views/Producto/register.php');
    }
    
    function save()
    {
        require_once('Views/Producto/bienvenido.php');
        $producto = new Producto(null,$_POST['nombre'],$_POST['unidades'],$_POST['precio']);
        Producto::save($producto);
    }
}//cierra clase