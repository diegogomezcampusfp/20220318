<?php

//controllers es la clase y la acción es el método
//los elementos del array son un listado de acciones

$controllers=array
(
    'producto'=>['index', 'show', 'save', 'create', 'update', 'delete', 'error'],
    'profesor'=>['index', 'show', 'save', 'create', 'update', 'delete', 'error'],
    'curso'=>['index', 'show', 'save', 'create', 'update', 'error']
);

if (array_key_exists($controller, $controllers))
{
    if (in_array($action,$controllers[$controller]))
    {
        call($controller,$action);
    }
    else
    {
        call($controller,'error');
    }
} 
else
{
    call($controller,'error');
}

function call($controller,$action)
{
    require_once('Controllers/'.$controller.'Controller.php');
    switch ($controller) {
        case 'producto':
            echo "<h3>Estoy en producto</h3>";
            require_once('Model/Producto.php');
            $controller=new ProductoController();
            break;
        case 'profesor':
            echo "<h3>Estoy en profesor</h3>"; 
            require_once('Model/Profesor.php');
            $controller=new ProfesorController();
            break;
        case 'curso':
            echo "<h3>Estoy en curso</h3>";
            require_once('Model/Curso.php');
            $controller=new CursoController();
             break;
        default:
            # code...
            break;
    }
    $controller->{$action}();
}